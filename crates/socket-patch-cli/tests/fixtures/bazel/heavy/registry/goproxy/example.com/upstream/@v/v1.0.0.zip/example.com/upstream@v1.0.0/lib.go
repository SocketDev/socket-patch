package upstream

func Greeting() string { return "PRISTINE" }
