VALUE = "vulnerable"


def value():
    return VALUE
