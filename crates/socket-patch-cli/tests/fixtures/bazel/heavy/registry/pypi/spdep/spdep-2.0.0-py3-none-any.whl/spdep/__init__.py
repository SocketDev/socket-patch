VALUE = "spdep-2.0.0"
